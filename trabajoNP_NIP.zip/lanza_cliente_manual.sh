#!/bin/bash

./bin/cliente $1 $2 manual
