#!/bin/bash

echo "Se lanza el servicio en el puerto 3000"
./bin/main 3000
